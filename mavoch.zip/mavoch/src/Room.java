import java.util.Set;

public class Room {

    private Settings.WallKind upperWall;
    private Settings.WallKind downWall;
    private Settings.WallKind leftWall;
    private Settings.WallKind rightWall;
    private Settings.RoomKind roomKind;
    private int xLocation = -1;
    private int yLocation = -1;
    private int prize = 0;

    // Constructor for room
    public Room(Settings.WallKind upperWall, Settings.WallKind downWall,
                Settings.WallKind leftWall, Settings.WallKind rightWall,
                Settings.RoomKind roomKind,
                int row, int col) {
        this.downWall = downWall;
        this.upperWall = upperWall;
        this.leftWall = leftWall;
        this.rightWall = rightWall;
        this.roomKind = roomKind;
        this.xLocation = col;
        this.yLocation = row;
    }

    public int getXLocation()
    {
        return this.xLocation;
    }
    public int getYLocation()
    {
        return this.yLocation;
    }
    public int getPrize(){
        return this.prize;
    }
    public void setPrize(){
        this.prize = Settings.Prize;
    }

    public Settings.WallKind getUpperWall() {
        return this.upperWall;
    }

    public Settings.WallKind getDownWall() {
        return this.downWall;
    }

    public Settings.WallKind getLeftWall() {
        return this.leftWall;
    }

    public Settings.WallKind getRightWall() {
        return this.rightWall;
    }

    public Settings.RoomKind getRoomKind() {
        return this.roomKind;
    }
}
