import java.lang.management.PlatformLoggingMXBean;
import java.nio.channels.SeekableByteChannel;
import java.util.ArrayList;
import java.util.Random;
import java.util.Scanner;
import java.util.Set;

public class Maze {
    Random rnd = new Random();
    private Room[][] maze;
    private Room prizeRoom;
    private int mazeHight=0;
    private int mazeWeight=0;
    private final int roomSize = 7;

    public int getMazeHight() {
    	return this.mazeHight;
    }
    
    public int getMazeWeight() {
    	return this.mazeWeight;
    }
    
    public Room getPrizeRoom()
    {
        return prizeRoom;
    }

    public Room getRandomExternalRoomWithDoorAndWithoutPrize(){
        ArrayList<Room> externalRooms = new ArrayList<>();
        for (int row = 0; row < getMazeHight(); row++) {
            for (int col = 0; col < getMazeWeight(); col++) {
                if (this.maze[row][col].getRoomKind() == Settings.RoomKind.ExternalWithExternalDoor) {

                    if (this.maze[row][col].getPrize() == 0) {
                        externalRooms.add(maze[row][col]);
                    }
                }
            }
        }
        // return one of the externals rooms
        return externalRooms.get(rnd.nextInt(externalRooms.size()));
    }

    public Room getRoomInPosition(int x,int y){
        return this.maze[y][x];
    }

    public void createMaze(int round) {
        if (round == 1){
            this.maze = new Room[5][3];
            this.mazeHight=5;
            this.mazeWeight=3;
            
            this.maze[0][0] = new Room(Settings.WallKind.DOOR, Settings.WallKind.DOOR, Settings.WallKind.WALL, Settings.WallKind.WALL, Settings.RoomKind.ExternalWithExternalDoor, 0,0);
            this.maze[0][1] = new Room(Settings.WallKind.DOOR, Settings.WallKind.DOOR, Settings.WallKind.DOOR, Settings.WallKind.DOOR, Settings.RoomKind.VOID, 0,1);
            this.maze[0][2] = new Room(Settings.WallKind.DOOR, Settings.WallKind.DOOR, Settings.WallKind.WALL, Settings.WallKind.WALL, Settings.RoomKind.ExternalWithExternalDoor, 0,2);
            this.maze[1][0] = new Room(Settings.WallKind.DOOR, Settings.WallKind.DOOR, Settings.WallKind.WALL, Settings.WallKind.DOOR, Settings.RoomKind.ExternalWithExternalDoor, 1,0);
            this.maze[1][1] = new Room(Settings.WallKind.WALL, Settings.WallKind.DOOR, Settings.WallKind.DOOR, Settings.WallKind.WALL, Settings.RoomKind.INTERNAL, 1,1);
            this.maze[1][2] = new Room(Settings.WallKind.DOOR, Settings.WallKind.DOOR, Settings.WallKind.WALL, Settings.WallKind.DOOR, Settings.RoomKind.ExternalWithExternalDoor, 1,2);
            this.maze[2][0] = new Room(Settings.WallKind.DOOR, Settings.WallKind.DOOR, Settings.WallKind.DOOR, Settings.WallKind.DOOR, Settings.RoomKind.VOID, 2,0);
            this.maze[2][1] = new Room(Settings.WallKind.DOOR, Settings.WallKind.DOOR, Settings.WallKind.DOOR, Settings.WallKind.DOOR, Settings.RoomKind.ExternalWithExternalDoor, 2,1);
            this.maze[2][2] = new Room(Settings.WallKind.DOOR, Settings.WallKind.DOOR, Settings.WallKind.DOOR, Settings.WallKind.WALL, Settings.RoomKind.ExternalWithExternalDoor, 2,2);
            this.maze[3][0] = new Room(Settings.WallKind.WALL, Settings.WallKind.DOOR, Settings.WallKind.DOOR, Settings.WallKind.DOOR, Settings.RoomKind.ExternalWithExternalDoor, 3,0);
            this.maze[3][1] = new Room(Settings.WallKind.DOOR, Settings.WallKind.WALL, Settings.WallKind.DOOR, Settings.WallKind.WALL, Settings.RoomKind.EXTERNAL, 3,1);
            this.maze[3][2] = new Room(Settings.WallKind.DOOR, Settings.WallKind.DOOR, Settings.WallKind.DOOR, Settings.WallKind.DOOR, Settings.RoomKind.VOID, 3,2);
            this.maze[4][0] = new Room(Settings.WallKind.DOOR, Settings.WallKind.DOOR, Settings.WallKind.WALL, Settings.WallKind.DOOR, Settings.RoomKind.ExternalWithExternalDoor, 4,0);
            this.maze[4][1] = new Room(Settings.WallKind.WALL, Settings.WallKind.DOOR, Settings.WallKind.DOOR, Settings.WallKind.DOOR, Settings.RoomKind.ExternalWithExternalDoor, 4,1);
            this.maze[4][2] = new Room(Settings.WallKind.WALL, Settings.WallKind.WALL, Settings.WallKind.DOOR, Settings.WallKind.WALL, Settings.RoomKind.EXTERNAL, 4,2);
            this.maze[4][2].setPrize();
            this.prizeRoom = this.maze[4][2];
        }
        else if (round == 2) {
            this.maze = new Room[5][4];
            this.mazeHight=5;
            this.mazeWeight=4;
            this.maze[0][0] = new Room(Settings.WallKind.WALL, Settings.WallKind.DOOR, Settings.WallKind.DOOR, Settings.WallKind.DOOR, Settings.RoomKind.ExternalWithExternalDoor, 0, 0);
            this.maze[0][1] = new Room(Settings.WallKind.WALL, Settings.WallKind.DOOR, Settings.WallKind.DOOR, Settings.WallKind.WALL, Settings.RoomKind.EXTERNAL, 0, 1);
            this.maze[0][2] = new Room(Settings.WallKind.DOOR, Settings.WallKind.DOOR, Settings.WallKind.WALL, Settings.WallKind.DOOR, Settings.RoomKind.ExternalWithExternalDoor, 0, 2);
            this.maze[0][3] = new Room(Settings.WallKind.WALL, Settings.WallKind.DOOR, Settings.WallKind.DOOR, Settings.WallKind.DOOR, Settings.RoomKind.ExternalWithExternalDoor, 0, 3);
            this.maze[1][0] = new Room(Settings.WallKind.DOOR, Settings.WallKind.DOOR, Settings.WallKind.DOOR, Settings.WallKind.DOOR, Settings.RoomKind.VOID, 1,0);
            this.maze[1][1] = new Room(Settings.WallKind.DOOR, Settings.WallKind.DOOR, Settings.WallKind.DOOR, Settings.WallKind.WALL, Settings.RoomKind.ExternalWithExternalDoor, 1, 1);
            this.maze[1][2] = new Room(Settings.WallKind.DOOR, Settings.WallKind.DOOR, Settings.WallKind.WALL, Settings.WallKind.WALL, Settings.RoomKind.ExternalWithExternalDoor, 1, 2);
            this.maze[1][3] = new Room(Settings.WallKind.DOOR, Settings.WallKind.DOOR, Settings.WallKind.DOOR, Settings.WallKind.DOOR, Settings.RoomKind.VOID, 1,3);
            this.maze[2][0] = new Room(Settings.WallKind.WALL, Settings.WallKind.DOOR, Settings.WallKind.WALL, Settings.WallKind.DOOR, Settings.RoomKind.ExternalWithExternalDoor, 2, 0);
            this.maze[2][1] = new Room(Settings.WallKind.DOOR, Settings.WallKind.DOOR, Settings.WallKind.DOOR, Settings.WallKind.DOOR, Settings.RoomKind.INTERNAL, 2, 1);
            this.maze[2][2] = new Room(Settings.WallKind.DOOR, Settings.WallKind.DOOR, Settings.WallKind.DOOR, Settings.WallKind.DOOR, Settings.RoomKind.ExternalWithExternalDoor, 2, 2);
            this.maze[2][3] = new Room(Settings.WallKind.DOOR, Settings.WallKind.DOOR, Settings.WallKind.DOOR, Settings.WallKind.DOOR, Settings.RoomKind.VOID, 2,3);
            this.maze[3][0] = new Room(Settings.WallKind.DOOR, Settings.WallKind.DOOR, Settings.WallKind.DOOR, Settings.WallKind.DOOR, Settings.RoomKind.VOID, 3,0);
            this.maze[3][1] = new Room(Settings.WallKind.DOOR, Settings.WallKind.DOOR, Settings.WallKind.WALL, Settings.WallKind.DOOR, Settings.RoomKind.ExternalWithExternalDoor, 3, 1);
            this.maze[3][2] = new Room(Settings.WallKind.DOOR, Settings.WallKind.DOOR, Settings.WallKind.DOOR, Settings.WallKind.DOOR, Settings.RoomKind.VOID, 3,2);
            this.maze[3][3] = new Room(Settings.WallKind.DOOR, Settings.WallKind.DOOR, Settings.WallKind.DOOR, Settings.WallKind.DOOR, Settings.RoomKind.VOID, 3,3);
            this.maze[4][0] = new Room(Settings.WallKind.DOOR, Settings.WallKind.DOOR, Settings.WallKind.DOOR, Settings.WallKind.DOOR, Settings.RoomKind.VOID, 4,0);
            this.maze[4][1] = new Room(Settings.WallKind.DOOR, Settings.WallKind.WALL, Settings.WallKind.WALL, Settings.WallKind.WALL, Settings.RoomKind.EXTERNAL, 4, 1);
            this.maze[4][2] = new Room(Settings.WallKind.DOOR, Settings.WallKind.DOOR, Settings.WallKind.DOOR, Settings.WallKind.DOOR, Settings.RoomKind.VOID, 4,2);
            this.maze[4][3] = new Room(Settings.WallKind.DOOR, Settings.WallKind.DOOR, Settings.WallKind.DOOR, Settings.WallKind.DOOR, Settings.RoomKind.VOID, 4,3);
            this.maze[4][1].setPrize();
            this.prizeRoom = this.maze[4][1];
        }
        else if (round == 3){
            this.maze = new Room[4][4];
            this.mazeHight=4;
            this.mazeWeight=4;
            this.maze[0][0] = new Room(Settings.WallKind.DOOR, Settings.WallKind.DOOR, Settings.WallKind.DOOR, Settings.WallKind.DOOR, Settings.RoomKind.VOID, 0,0);
            this.maze[0][1] = new Room(Settings.WallKind.DOOR, Settings.WallKind.DOOR, Settings.WallKind.DOOR, Settings.WallKind.DOOR, Settings.RoomKind.VOID, 0,1);
            this.maze[0][2] = new Room(Settings.WallKind.DOOR, Settings.WallKind.DOOR, Settings.WallKind.DOOR, Settings.WallKind.DOOR, Settings.RoomKind.VOID, 0,2);
            this.maze[0][3] = new Room(Settings.WallKind.DOOR, Settings.WallKind.DOOR, Settings.WallKind.WALL, Settings.WallKind.WALL, Settings.RoomKind.ExternalWithExternalDoor, 0,3);
            this.maze[1][0] = new Room(Settings.WallKind.DOOR, Settings.WallKind.DOOR, Settings.WallKind.DOOR, Settings.WallKind.DOOR, Settings.RoomKind.VOID, 1,0);
            this.maze[1][1] = new Room(Settings.WallKind.DOOR, Settings.WallKind.DOOR, Settings.WallKind.DOOR, Settings.WallKind.DOOR, Settings.RoomKind.VOID, 1,1);
            this.maze[1][2] = new Room(Settings.WallKind.WALL, Settings.WallKind.DOOR, Settings.WallKind.DOOR, Settings.WallKind.DOOR, Settings.RoomKind.ExternalWithExternalDoor, 1,2);
            this.maze[1][3] = new Room(Settings.WallKind.DOOR, Settings.WallKind.DOOR, Settings.WallKind.DOOR, Settings.WallKind.DOOR, Settings.RoomKind.ExternalWithExternalDoor, 1,3);
            this.maze[2][0] = new Room(Settings.WallKind.DOOR, Settings.WallKind.DOOR, Settings.WallKind.DOOR, Settings.WallKind.DOOR, Settings.RoomKind.VOID, 2,0);
            this.maze[2][1] = new Room(Settings.WallKind.DOOR, Settings.WallKind.WALL, Settings.WallKind.DOOR, Settings.WallKind.DOOR, Settings.RoomKind.ExternalWithExternalDoor, 2,1);
            this.maze[2][2] = new Room(Settings.WallKind.DOOR, Settings.WallKind.DOOR, Settings.WallKind.DOOR, Settings.WallKind.DOOR, Settings.RoomKind.INTERNAL, 2,2);
            this.maze[2][3] = new Room(Settings.WallKind.DOOR, Settings.WallKind.WALL, Settings.WallKind.DOOR, Settings.WallKind.DOOR, Settings.RoomKind.ExternalWithExternalDoor, 2,3);
            this.maze[3][0] = new Room(Settings.WallKind.WALL, Settings.WallKind.WALL, Settings.WallKind.WALL, Settings.WallKind.DOOR, Settings.RoomKind.EXTERNAL, 3,0);
            this.maze[3][1] = new Room(Settings.WallKind.WALL, Settings.WallKind.DOOR, Settings.WallKind.DOOR, Settings.WallKind.DOOR, Settings.RoomKind.ExternalWithExternalDoor, 3,1);
            this.maze[3][2] = new Room(Settings.WallKind.DOOR, Settings.WallKind.WALL, Settings.WallKind.DOOR, Settings.WallKind.DOOR, Settings.RoomKind.ExternalWithExternalDoor, 3,2);
            this.maze[3][3] = new Room(Settings.WallKind.DOOR, Settings.WallKind.DOOR, Settings.WallKind.DOOR, Settings.WallKind.DOOR, Settings.RoomKind.VOID, 3,3);
            this.maze[3][0].setPrize();
            this.prizeRoom = this.maze[3][0];
        }
    }

    public void printMaze(ArrayList<Player> players) {
        // For all the rows
        for (int row = 0; row < getMazeHight(); row++) {
            // For upper Wall
            for (int col = 0; col < getMazeWeight(); col++) {
                // Check upper wall if it is a door or a wall
                if (this.maze[row][col].getRoomKind() == Settings.RoomKind.VOID) {
                    for (int i = 0; i < this.roomSize; i++) {
                        System.out.print(" ");
                    }
                } else if (this.maze[row][col].getUpperWall() == Settings.WallKind.WALL) {
                    // print the wall
                    // 7 is the room size in chars
                    for (int i = 0; i < this.roomSize; i++) {
                        System.out.print("#");
                    }
                } else {
                    // print the wall
                    // 7 is the room size in chars
                    for (int i = 0; i < this.roomSize; i++) {
                        System.out.print("-");
                    }
                }
            }
            System.out.println("");

            for (int hight = 0; hight < this.roomSize -2 ; hight++) {
                // For left Wall
                for (int col = 0; col < getMazeWeight(); col++) {
                    Boolean isPlayerNamePrinted = false;
                    // Check left wall if it is a door or a wall
                    if (this.maze[row][col].getRoomKind() == Settings.RoomKind.VOID) {
                        System.out.print(" ");
                    } else if (this.maze[row][col].getLeftWall() == Settings.WallKind.WALL) {
                        // print the wall
                        System.out.print("#");
                    } else {
                        // print the wall
                        System.out.print("|");
                    }

                    // Print players
                    int playerNumberInThatRoom = 0;

                    for (Player player : players) {
                        if (player.getxLocation() == col && player.getyLocation() == row) {
                            if (playerNumberInThatRoom == hight) {
                                System.out.print(player.getPlayerName());
                                isPlayerNamePrinted = true;
                            }
                            playerNumberInThatRoom++;
                        }
                    }

                    if (!isPlayerNamePrinted) {
                        // Print space instead of player name
                        for (int i = 0; i < this.roomSize - 2; i++) {
                            if (i == 2 && hight == this.roomSize - 3) {
                                if (this.maze[row][col].getPrize() != 0) {
                                    System.out.print(this.maze[row][col].getPrize());
                                    i++;
                                }
                            }
                            System.out.print(" ");
                        }
                    }
                    if (this.maze[row][col].getRoomKind() == Settings.RoomKind.VOID) {
                        System.out.print(" ");
                    }
                    // Check right wall if it is a door or a wall
                    else if (this.maze[row][col].getRightWall() == Settings.WallKind.WALL) {
                        // print the wall
                        System.out.print("#");
                    } else {
                        // print the wall
                        System.out.print("|");
                    }
                }
                System.out.println("");
            }
            // Check down wall
            for (int col = 0; col < this.maze[0].length; col++) {
                if (this.maze[row][col].getRoomKind() == Settings.RoomKind.VOID) {
                    for (int i = 0; i < this.roomSize; i++) {
                        System.out.print(" ");
                    }
                }
                // Check upper wall if it is a door or a wall
                else if (this.maze[row][col].getDownWall() == Settings.WallKind.WALL) {
                    // print the wall
                    // 7 is the room size in chars
                    for (int i = 0; i < this.roomSize; i++) {
                        System.out.print("#");
                    }
                } else {
                    // print the wall
                    // 7 is the room size in chars
                    for (int i = 0; i < this.roomSize; i++) {
                        System.out.print("-");
                    }
                }
            }
            System.out.println("");
        }
    }
}
