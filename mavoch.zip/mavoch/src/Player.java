public class Player {
    private int score = 0;
    private int xLocation;
    private int yLocation;
    private String playerName;
    private boolean isPlayerBot;
    private boolean isPlayerCanPlay = true;

    public Player(String playerName){
        this.playerName = playerName.substring(0,5);
    }
    
    public int getPlayerScore(){
        return score;
    }

    public int getxLocation()
    {
        return this.xLocation;
    }
    public int getyLocation()
    {
        return this.yLocation;
    }

    public boolean isPlayerCanPlay()
    {
        return this.isPlayerCanPlay;
    }

    public String getPlayerName()
    {
        return this.playerName;
    }
    
    public void setPlayerPosition(int xLocation,int yLocation){
        this.xLocation = xLocation;
        this.yLocation = yLocation;
    }

    // Do move for player if the move is valid.
    // Return result if the move was valid
    public boolean movePlayer(int xlocation, int yLocation, int mazeHight, int mazeWeight){
        boolean moveSuccess = false;
        if (this.yLocation - yLocation == 0 && Math.abs(this.xLocation - xlocation) == 1 && (this.xLocation >= 0 && this.xLocation < mazeWeight)){
            this.xLocation = xlocation;
            this.score--;
            moveSuccess =  true;
        }
        if (this.xLocation - xlocation == 0 && Math.abs(this.yLocation - yLocation) == 1 && (this.yLocation >= 0 && this.yLocation < mazeHight)){
            this.yLocation = yLocation;
            this.score--;
            moveSuccess =  true;
        }
        if (this.xLocation < 0 || xLocation >= mazeWeight  ||
                this.yLocation < 0 || this.yLocation >= mazeHight)
        {
            setPlayerCanPlay(false);
        }
        if (!moveSuccess)
        {
        	setPlayerCanPlay(false);
        }
        
        return moveSuccess;
    }

    public void useHint()
    {
        this.score--;
    }

    public void setPlayerCanPlay(Boolean isPlayerCanPlay){
        this.isPlayerCanPlay = isPlayerCanPlay;
    }
    
    public void playerFoundPrize(int prizeSize){
        this.score += prizeSize;
    }
}