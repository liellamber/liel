public class Settings {

    public static enum WallKind {DOOR, WALL};
    public static enum RoomKind {EXTERNAL,ExternalWithExternalDoor, INTERNAL,VOID}
    public static int Rounds = 3;
    public static Boolean printMazeAfterEveryMove = true;
    public static int Prize = 9;
}