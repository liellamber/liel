import java.util.ArrayList;
import java.util.Scanner;

public class Game {

    private final Scanner sc = new Scanner(System.in);
    private final ArrayList<Player> players = new ArrayList<>();
    private final Maze maze = new Maze();

    public void start() {
        // Create players
        createPlayers();

        for (int round =1 ; round <= Settings.Rounds; round++)
        {
            System.out.println("Round " + round);

            // Prepare the maze and players
            initRound(round);
            // Start play the round
            playRound(round);
            // print player scores
            printPlayerScores();
        }
        printEndGame();
    }

    private void initRound(int round){
        // Create a maze
        this.maze.createMaze(round);
        // Set players position for this round
        setPlayersPosition();
    }

    private void playRound(int round) {
        boolean gameOver = false;

        // While game is not over
        while (!gameOver) {
            gameOver = true;
            if (Settings.printMazeAfterEveryMove){
               this.maze.printMaze(players);
            }
            //Do move for all player that can
            for (Player player : this.players) {
                if (player.isPlayerCanPlay()) {
                    // Show player option to play and save the move
                    movePlayer(player);
                    // Validate if player can play in the next move
                    // If none of the player can move the game is over
                    if (player.isPlayerCanPlay()){
                        gameOver = false;
                    }
                }
            }
        }
        System.out.println("Round number " + round + " ended");
    }

    // Find the best player and print his name
    private void printEndGame(){
        Player bestplayer = this.players.get(0);
        for (Player player : this.players) {
            if (bestplayer.getPlayerScore() < player.getPlayerScore()){
                bestplayer = player;
            }
        }
        System.out.println("All the round over and the winner is: "+ bestplayer.getPlayerName());
        System.out.println("With score: " + bestplayer.getPlayerScore());
    }

    private void printPlayerScores()
    {
        System.out.println("Player Scores: ");
        for (Player player : this.players) {
            System.out.println(player.getPlayerName() + " with score: " + player.getPlayerScore());
        }
    }

    private void movePlayer(Player player) {
    	// Check if the player can move
        if (player.isPlayerCanPlay()) {
            System.out.println(player.getPlayerName() + " Please choose option");
            Room m = this.maze.getRoomInPosition(player.getxLocation(), player.getyLocation());
            if (m.getUpperWall() == Settings.WallKind.DOOR) {
                System.out.println("Press W for up");
            }
            if (m.getDownWall() == Settings.WallKind.DOOR) {
                System.out.println("Press S for down");
            }
            if (m.getLeftWall() == Settings.WallKind.DOOR) {
                System.out.println("Press A for left");
            }
            if (m.getRightWall() == Settings.WallKind.DOOR) {
                System.out.println("Press D for right");
            }

            System.out.println("Press B to stay");
            System.out.println("Press Q to get distance from the prize. This hint will cost you a move");
            System.out.println("Press E to get information about near room.");

            // Get the decision 
            String playerMove = this.sc.nextLine();

            while (playerMove.equalsIgnoreCase("W") && m.getUpperWall() == Settings.WallKind.WALL ||
                    playerMove.equalsIgnoreCase("A") && m.getLeftWall() == Settings.WallKind.WALL ||
                    playerMove.equalsIgnoreCase("S") && m.getDownWall() == Settings.WallKind.WALL ||
                    playerMove.equalsIgnoreCase("D") && m.getRightWall() == Settings.WallKind.WALL ||
                    (!playerMove.equalsIgnoreCase("W") &&
                     !playerMove.equalsIgnoreCase("A") &&
                     !playerMove.equalsIgnoreCase("S") &&
                     !playerMove.equalsIgnoreCase("D") &&
                     !playerMove.equalsIgnoreCase("B") &&
                     !playerMove.equalsIgnoreCase("Q") && 
                     !playerMove.equalsIgnoreCase("E"))) {
                System.out.println("Invalid move please choose again");
                playerMove = this.sc.nextLine();
            }

            if (playerMove.equalsIgnoreCase("W")) {
            	player.movePlayer(player.getxLocation(), player.getyLocation() - 1, this.maze.getMazeHight(), this.maze.getMazeWeight());
            }
            if (playerMove.equalsIgnoreCase("A")) {
            	player.movePlayer(player.getxLocation() - 1, player.getyLocation(), this.maze.getMazeHight(), this.maze.getMazeWeight());
            }
            if (playerMove.equalsIgnoreCase("S")) {
                player.movePlayer(player.getxLocation(), player.getyLocation() + 1, this.maze.getMazeHight(), this.maze.getMazeWeight());
            } 
            if (playerMove.equalsIgnoreCase("D")) {
                player.movePlayer(player.getxLocation() + 1, player.getyLocation(), this.maze.getMazeHight(), this.maze.getMazeWeight());
            }

            if (playerMove.equalsIgnoreCase("Q")) {
                int distance = Math.abs(player.getxLocation() - maze.getPrizeRoom().getXLocation()) * Math.abs(player.getxLocation() - maze.getPrizeRoom().getXLocation())
                        + Math.abs(player.getyLocation() - maze.getPrizeRoom().getYLocation()) *
                        Math.abs(player.getyLocation() - maze.getPrizeRoom().getYLocation());
                System.out.println("Your air distance from the prize is : " + (int)Math.ceil(Math.sqrt(distance)));
                player.useHint();
            }
            if (playerMove.equalsIgnoreCase("E")) {

                System.out.println("Please choose near room with direction (W,A,S,D)");
                String hintRoom = this.sc.nextLine();

                int ypos = player.getyLocation();
                int xpos = player.getxLocation();
                if (hintRoom.equalsIgnoreCase("W")) {
                    ypos--;
                }
                if (hintRoom.equalsIgnoreCase("A")) {
                    xpos--;
                }
                if (hintRoom.equalsIgnoreCase("S")) {
                    ypos++;
                }
                if (hintRoom.equalsIgnoreCase("D")) {
                    xpos++;
                }
                if (xpos < 0 || xpos >= this.maze.getMazeWeight() || ypos < 0 || ypos >= this.maze.getMazeHight() ){
                    System.out.println("This room is out of bound");
                }
                else
                {
                    Room eHintRoom = this.maze.getRoomInPosition(xpos,ypos);
                    System.out.println("The room kind is: " + eHintRoom.getRoomKind());
                    if (eHintRoom.getPrize()>0){
                        System.out.println("This room contain the prize");
                    }
                }
                player.useHint();
            }
            // Check if player won
            if (this.maze.getPrizeRoom().getYLocation() == player.getyLocation() &&
                    this.maze.getPrizeRoom().getXLocation() == player.getxLocation()) {
                player.playerFoundPrize(this.maze.getPrizeRoom().getPrize());
                player.setPlayerCanPlay(false);
            }

            // Check if player in void
            if (player.getxLocation() >= 0 && player.getxLocation() < this.maze.getMazeWeight() &&
                    player.getyLocation() >= 0 && player.getyLocation() < this.maze.getMazeHight()) {
                if (this.maze.getRoomInPosition(player.getxLocation(), player.getyLocation()).getRoomKind() == Settings.RoomKind.VOID) {
                    player.setPlayerCanPlay(false);
                }
            }
        }
    }
    

    private void setPlayersPosition(){
        for (Player player: this.players){
            // Find external random room to set the player in
            Room randomRoom = this.maze.getRandomExternalRoomWithDoorAndWithoutPrize();
            player.setPlayerPosition(randomRoom.getXLocation(),randomRoom.getXLocation());
            player.setPlayerCanPlay(true);
        }
    }

    private void createPlayers() {
        try {
            int playerNumber;
            // Set number of players
            System.out.println("Please Insert Number Of Real Players:");
            playerNumber = Integer.parseInt(this.sc.nextLine());
            for (int i = 1; i <= playerNumber; i++) {
                System.out.println("Please Insert Player " + i + " Player Name:");
                String playerName = this.sc.nextLine();
                Player p = new Player(playerName+"     ");
                this.players.add(p);
            }
        } catch (Exception e) {
            createPlayers();
        }
    }
}
